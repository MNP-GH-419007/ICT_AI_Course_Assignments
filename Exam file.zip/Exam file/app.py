import streamlit as st
import joblib

# Load model and vectorizer
model = joblib.load("tfidf_logistic_model.pkl")
vectorizer = joblib.load("tfidf_vectorizer.pkl")
id2label = joblib.load("label_mapping.pkl")

def clean_text(text):
    import re, string
    text = text.lower()
    text = re.sub(r"http\\S+|www\\S+|https\\S+", '', text)
    text = re.sub(r"@\\w+|#", '', text)
    text = re.sub(r"[^\\w\\s]", '', text)
    text = re.sub(r"\\d+", '', text)
    text = text.translate(str.maketrans('', '', string.punctuation))
    return text.strip()

st.title("Tweet Emotion Detection")

tweet = st.text_area("Enter a tweet:")
if st.button("Predict Emotion"):
    cleaned = clean_text(tweet)
    vec = vectorizer.transform([cleaned])
    pred = model.predict(vec)[0]
    prob = model.predict_proba(vec)[0]
    st.write(f"**Predicted Emotion:** {id2label[pred]}")
    st.write("**Probabilities:**")
    for i, p in enumerate(prob):
        st.write(f"{id2label[i]}: {p:.4f}")